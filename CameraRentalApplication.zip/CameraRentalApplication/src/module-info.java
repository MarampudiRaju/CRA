/**
 * 
 */
/**
 * @author NARASIMHA
 *
 */
module CameraRentalApplication {
}