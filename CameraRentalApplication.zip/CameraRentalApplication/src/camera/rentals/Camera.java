package camera.rentals;

public class Camera {
	 private String brand;
	    private String model;
	    private double rentPerDay;
	    private boolean isRented;
	

	    
	    
	    
	   public Camera(String brand, String model, double rentPerDay) {
	        this.brand = brand;
	        this.model = model;
	        this.rentPerDay = rentPerDay;
	    }

	    public String getBrand() {
	        return brand;
	    }

	    public String getModel() {
	        return model;
	    }

	    public double getRentPerDay() {
			return rentPerDay;
	    	
	    }
	    public boolean isRented() {
	        return isRented;
	    }

	    public void setRented(boolean rented) {
	        isRented = rented;
	    }
}