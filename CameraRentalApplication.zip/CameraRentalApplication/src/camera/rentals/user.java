package camera.rentals;
import java.util.Scanner;

class User {
    private String username;
    private String password;

    public User() {
        username = "Raju";
        setPassword("raju123");
    }

    public void login(CameraRentalSystem rentalSystem) {
        Scanner sc = new Scanner(System.in);
    	System.out.println("+--------------------------------------------+");
		System.out.println("|    Welcome to Camera Rental Application    |");
		System.out.println("+--------------------------------------------+");
		System.out.println("Please Login to Continue");

        System.out.print("Enter the Username:");
        String uname = sc.nextLine();
        System.out.print("Enter Password:");
        String pname = sc.nextLine();

        if (uname.equals(username) && pname.equals(getPassword())) {
            System.out.println("Login successful!!");
            rentalSystem.displayMenu();
        } else {
            System.out.println("Incorrect credentials. Try again!");
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
