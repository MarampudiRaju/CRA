package camera.rentals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CameraRentalSystem {
    private List<Camera> cameraList;
    private double userWalletBalance;
    
    public static void main(String[] args) {
        CameraRentalSystem rentalSystem = new CameraRentalSystem();
        rentalSystem.addCamerasToList();
        User u = new User();
        u.login(rentalSystem);
    }

    public CameraRentalSystem() {
        cameraList = new ArrayList<>();
        userWalletBalance = 1000.0;
    }

    public void addCamera(String brand, String model, double rentPerDay) {
        Camera camera = new Camera(brand, model, rentPerDay);
        cameraList.add(camera);
    }
    public void addCamerasToList() {
        addCamera("Nikon","Nikon D850", 1500.00);
        addCamera("Canon","Canon EOS 5D Mark IV", 1200.00);
        addCamera("Olympus","Olympus OM-D E-M1 Mark III", 2000.00);
        addCamera("Sony","Sony Alpha a7 III", 1800.00);
        addCamera("Panasonic","Panasonic Lumix GH5", 2500.00);
        addCamera("Fujifilm","Fujifilm X-T4", 2600.00);
    }

    public void removeCamera() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available.");
        } else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter camera index to remove:");
            int cameraIndex = sc.nextInt();
            if (cameraIndex >= 0 && cameraIndex < cameraList.size()) {
                Camera removedCamera = cameraList.remove(cameraIndex);
                System.out.println("Removed camera: " + removedCamera.getBrand() + " " + removedCamera.getModel());
            } else {
                System.out.println("Invalid camera index.");
            }
        }
        
    }

    public void displayCameraList() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available.");
        } else {
            System.out.println("+-----------------------------------------------------------------------------+");
            System.out.println("|                            Available Cameras                                |");
            System.out.println("+-----------------------------------------------------------------------------+");
            System.out.printf("| %-4s| %-15s | %-25s | %-10s | %-8s  | \n", "Index", "Brand", "Model", "Rent/Day", "Status");
            System.out.println("+-----------------------------------------------------------------------------+");

            for (int i = 0; i < cameraList.size(); i++) {
                Camera camera = cameraList.get(i);
                String status = camera.isRented() ? "Rented" : "Available";
                System.out.printf("| %-5d| %-16s| %-26s| $%-9.2f | %-8s |\n", i, camera.getBrand(), camera.getModel(), camera.getRentPerDay(), status);
                System.out.println("+-----------------------------------------------------------------------------+");
            }
        }
    }


    public void rentCamera(int cameraIndex) {
        if (cameraIndex >= 0 && cameraIndex < cameraList.size()) {
            Camera camera = cameraList.get(cameraIndex);
            if (camera.isRented()) {
                System.out.println("Camera already rented.");
            } else {
                double rentPerDay = camera.getRentPerDay();
                if (userWalletBalance >= rentPerDay) {
                    System.out.println("Renting camera: " + camera.getBrand() + " " + camera.getModel());
                    camera.setRented(true);
                    userWalletBalance -= rentPerDay;
                    System.out.println("Camera rented successfully!");
                    System.out.println("Wallet balance after rent: $" + userWalletBalance);
                } else {
                    System.out.println("Insufficient funds in the wallet.");
                    double NeedFunds=rentPerDay-userWalletBalance;
                    System.out.println("You need more: $"+NeedFunds+" to take Rent");

                }
            }
        } else {
            System.out.println("Invalid camera index.");
        }
    }
    public void displaySubMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Wallet Menu:");
            System.out.println("1.Deposit Amount");
            System.out.println("2.View Wallet Balance");
            System.out.println("3.Go Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to deposit: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    depositAmount(amount);
                    break;
                case 2:
                    viewWalletBalance();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println();
        }
    }

    public void depositAmount(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be greater than zero.");
        } else {
            userWalletBalance += amount;
            System.out.println("Deposit successful. Current wallet balance: $" + userWalletBalance);
        }
    }

    public void viewWalletBalance() {
        System.out.println("Current wallet balance: $" + userWalletBalance);
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1.My Camera");
            System.out.println("2.Rent a camera");
            System.out.println("3.Display available cameras");
            System.out.println("4.My Wallet");
            System.out.println("5.Exit");
            System.out.print("Choose an option from the above: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                	System.out.println("1.Add");
                	System.out.println("2.Remove");
                	System.out.println("3.View My Cameras");
                	System.out.println("4.Back to Previous Menu");
                	System.out.print("Select option from above: ");
                    int option = scanner.nextInt();
                    if (option == 1) {
                        scanner.nextLine(); // Consume the remaining newline character
                        System.out.print("Enter camera brand: ");
                        String brand = scanner.nextLine();
                        System.out.print("Enter camera model: ");
                        String model = scanner.nextLine();
                        System.out.print("Enter per-day rent amount: ");
                        double rentPerDay = scanner.nextDouble();
                        scanner.nextLine(); // Consume the remaining newline character
                        addCamera(brand, model, rentPerDay);
                        System.out.println("Camera added successfully");
                        displayCameraList();
                        break;
                    }

                	else if(option==2)
                	{
                		removeCamera();
                		System.out.println("Camera Removed successfully");
                		break;
                	}
                	else if(option==3)
                	{
                	    displayCameraList();
                	    break;

                	}
                	else if (option==4)
                	{
                	   break;
                	}
                	else
                	{
                		System.out.println("Invalid Choice");
                		break;
                	}
                    case 2:
                    displayCameraList();
                    System.out.print("Select a camera to rent (enter the index): ");
                    int cameraIndex = scanner.nextInt();
                    scanner.nextLine();
                    rentCamera(cameraIndex);
                    break;

                case 3:
                    displayCameraList();
                    break;
                case 4:
                    displaySubMenu();
                    break;
                case 5:
                    System.out.println("Exiting the application.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
            System.out.println();
        }
    }
    
   
  

  
}
